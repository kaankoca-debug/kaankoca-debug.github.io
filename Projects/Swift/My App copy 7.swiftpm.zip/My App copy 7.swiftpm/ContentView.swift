//18/11/2025
import SwiftUI
struct ContentView: View {
    let flavorList = ["Chocolate",
                    "Vanilla",
                    "Strawberry",
                    "Nutella"]
    //I created a list that contains 4 types of ice cream flavors in it. 
    
    let priceList = ["2 Dollars",
                     "2 Dollars",
                     "3 Dollars",
                     "4 Dollars"]
    //Then I created another list that contains the prices of these flavors. 
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("🍦 Ice Cream Shop")
                .font(.title)
                .bold()
                .padding()
            //I wrote the title to the ice cream shop. 
            
            ForEach(flavorList.indices, id: \.self) { step in
                HStack {
                    Text(flavorList[step])
                    Spacer()
                    //I used ForEach to create a statement for all the items in the list. I wrote all the steps of the flavorList. Then used a spacer to push the next texts to the other side of the screen. 
                    
                    Text("\(priceList[step])")
                    //Finally I printed out the prices of the flavors in order. 
                }
            }
        }
    }
}
