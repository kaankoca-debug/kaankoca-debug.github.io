//18/11/2025
import SwiftUI
struct ContentView: View {
    let CityList = ["🇹🇷 İstanbul",
                    "🏴󠁧󠁢󠁥󠁮󠁧󠁿 London",
                    "🇺🇸 Texas",
                    "🇫🇷 Nice"]
    //I created a list that contains 4 cities that have different times. 
    
    let ClockList = ["10:21",
                     "08:21",
                     "02:21",
                     "09:21"]
    //Than I created a list that contains the times in the cities when the time in Istanbul is 10:21. 
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("City Clock")
                .font(.title)
                .bold()
                .padding()
            //I wrote the title which is "City Clock".
            
            ForEach(CityList.indices, id: \.self) { step in
                HStack {
                    Text(CityList[step])
                    Spacer()
                    //I used ForEach to create a statement for each of the items in the citylist. I wrote down the citylist steps. Used a spacer to push the next items to the right side of the screen.
                    
                    Text("(\(ClockList[step]))")
                    //Then I wrote the times to the right side. 
                }
            }
        }
    }
}
