//23/11/2025
import SwiftUI
struct ContentView: View {
    @State private var selectedEmoji = "🟩" // Stores the currently selected emoji and the starting emoji is 🟩. 
    var body: some View {
        VStack(spacing: 10) {
            
            // Emoji selection buttons
            HStack(spacing: 5) {
                Button("🇹🇷") { selectedEmoji = "🇹🇷" }
                Button("🤕") { selectedEmoji = "🤕" }
                Button("🙃") { selectedEmoji = "🙃" }
                Button("🌝") { selectedEmoji = "🌝" }
                Button("🟧") { selectedEmoji = "🟧" }
                Button("❤️‍🔥") { selectedEmoji = "❤️‍🔥" }
                Button("🔱") { selectedEmoji = "🔱" }
                Button("🐣") { selectedEmoji = "🐣" }
                Button("👺") { selectedEmoji = "👺" }
                Button("🥳") { selectedEmoji = "🥳" }
            }
            // Display two Ks side by side
            HStack(spacing: 4) {
                LetterK(emoji: selectedEmoji) // Draw the first K
                LetterK(emoji: selectedEmoji) // Draw the second K
            }
        }
    }
}
// Function that draws one K using a 10x10 emoji grid
func LetterK(emoji: String) -> some View {
    let empty = "⬜️" // Emoji for empty cells
    // Pattern of the K: 1 = filled, 0 = empty
    let pattern: [[Int]] = [
        [1,0,0,0,0,1,0,0,0,0],
        [1,0,0,0,1,0,0,0,0,0],
        [1,0,0,1,0,0,0,0,0,0],
        [1,0,1,0,0,0,0,0,0,0],
        [1,1,0,0,0,0,0,0,0,0],
        [1,1,0,0,0,0,0,0,0,0],
        [1,0,1,0,0,0,0,0,0,0],
        [1,0,0,1,0,0,0,0,0,0],
        [1,0,0,0,1,0,0,0,0,0],
        [1,0,0,0,0,1,0,0,0,0]
    ]
    // Stack rows vertically
    return VStack(spacing: 0) {
        ForEach(0..<10, id: \.self) { row in
            // Stack columns horizontally inside each row
            HStack(spacing: 0) {
                ForEach(0..<10, id: \.self) { col in
                    // Show selected emoji if pattern is 1, else show empty emoji
                    Text(pattern[row][col] == 1 ? emoji : empty)
                        .font(.system(size: 20))
                }
            }
        }
    }
}
