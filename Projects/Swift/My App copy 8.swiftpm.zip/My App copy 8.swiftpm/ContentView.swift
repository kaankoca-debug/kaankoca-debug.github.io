//23/11/2025
import SwiftUI

struct ContentView: View {
    var body: some View {
        // Display two Ks side by side with some space in between
        HStack(spacing: 20) {
            LetterK()  // First K
            LetterK()  // Second K
        }
        .padding()  // Add some padding around the whole HStack
    }
}

// This is a function that draws the letter K using a 10x10 grid of circles
func LetterK() -> some View {
    let gridSize = 10        // The grid is 10 rows by 10 columns
    let circleSize: CGFloat = 20  // Each circle is 20x20 points in size
    let spacing: CGFloat = 4      // Space between circles
    
    // Here I chose which circles are filled to make the K shape
    // 1 = red circle which are filled, 0 = gray circle which are empty
    let pattern: [[Int]] = [
        [1,0,0,0,0,1,0,0,0,0],
        [1,0,0,0,1,0,0,0,0,0],
        [1,0,0,1,0,0,0,0,0,0],
        [1,0,1,0,0,0,0,0,0,0],
        [1,1,0,0,0,0,0,0,0,0],
        [1,1,0,0,0,0,0,0,0,0],
        [1,0,1,0,0,0,0,0,0,0],
        [1,0,0,1,0,0,0,0,0,0],
        [1,0,0,0,1,0,0,0,0,0],
        [1,0,0,0,0,1,0,0,0,0]
    ]
    
    // Build the actual grid of circles using VStack and HStack
    return VStack(spacing: spacing) {
        ForEach(0..<gridSize, id: \.self) { row in
            HStack(spacing: spacing) {
                ForEach(0..<gridSize, id: \.self) { col in
                    Circle()
                        .fill(pattern[row][col] == 1 ? Color.red : Color.gray.opacity(0.2)) // Fill red if 1, otherwise gray
                        .frame(width: circleSize, height: circleSize)  // Set the size of each circle
                }
            }
        }
    }
}
